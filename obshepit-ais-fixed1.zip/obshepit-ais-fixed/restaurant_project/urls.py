from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('admin/backup/', include('restaurant.backup_urls')),
    path('', include('restaurant.urls')),
]
